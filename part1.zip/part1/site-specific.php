<?php
require_once('sublan_calc.php');
require_once('email_custom.php');
require_once('jansamarth-specific.php');
require_once('/var/www/lt-specific/queue/single_txn_runner.php');
require_once('curl.php');
require_once('FileEncryptDecrypt.php');
use setasign\Fpdi\Tcpdf\Fpdi;
function getEnvType(){
 $env='UAT';
 return $env;
}

function bom_api_call($data){

	$curl = curl_init();


	curl_setopt_array($curl, array(

		CURLOPT_URL => $data['url'],

		CURLOPT_RETURNTRANSFER => true,
  
		//	CURLOPT_PROXY=>'10.120.0.83:8080',
		 CURLOPT_PROXY=>'10.132.106.4:8080',
  
		CURLOPT_HTTPPROXYTUNNEL => 1,

                 CURLOPT_SSL_VERIFYPEER=>FALSE,
  
		CURLOPT_ENCODING => '',
  
		CURLOPT_MAXREDIRS => 10,
  
		CURLOPT_TIMEOUT => 0,
  
		CURLOPT_FOLLOWLOCATION => true,

                CURLOPT_SSL_VERIFYPEER=>FALSE,
  
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  
		CURLOPT_CUSTOMREQUEST => $data['request_type'],
  
		CURLOPT_POSTFIELDS => $data['body'],
		CURLOPT_HTTPHEADER => $data['headers']
	));
	
	$response = curl_exec($curl);
	$err = curl_error($curl);

	curl_close($curl);
      
	if($err)
		return array("status" => "error", "message" => $err);
	else
		return array("status" => "success", "data" => $response);

}

/**
 * Returns array converted from xml
 */
function xmlToArray($xml){
libxml_use_internal_errors(true);
$xml = simplexml_load_string($xml, "SimpleXMLElement", LIBXML_NOCDATA);
if ($xml === false){
libxml_clear_errors();
return false;
}
$json = json_encode($xml);
return json_decode($json,TRUE);
}

/**
 * Return data between TransformedResponseXML tag in cibil
 */
function contentBetweenTags($content, $tagname){
$pattern = "#<\s*?$tagname\b[^>]*>(.*?)</$tagname\b[^>]*>#s";
    preg_match($pattern, $content, $matches);

if(empty($matches))
return;

$str = "<$tagname>".html_entity_decode($matches[1])."</$tagname>";
    return $str;
}

function w2n($number)
{

$number = (float)$number;

$numberbreaks=explode(".",$number);

    $no = $numberbreaks[0];
   $point = round($number - $no, 2) * 100;
   $hundred = null;
   $digits_1 = strlen($no);
   $i = 0;
   $str = array();
   $words = array('0' => '', '1' => 'one', '2' => 'two',
    '3' => 'three', '4' => 'four', '5' => 'five', '6' => 'six',
    '7' => 'seven', '8' => 'eight', '9' => 'nine',
    '10' => 'ten', '11' => 'eleven', '12' => 'twelve',
    '13' => 'thirteen', '14' => 'fourteen',
    '15' => 'fifteen', '16' => 'sixteen', '17' => 'seventeen',
    '18' => 'eighteen', '19' =>'nineteen', '20' => 'twenty',
    '30' => 'thirty', '40' => 'forty', '50' => 'fifty',
    '60' => 'sixty', '70' => 'seventy',
    '80' => 'eighty', '90' => 'ninety');
   $digits = array('', 'hundred', 'thousand', 'lakh', 'crore');
   while ($i < $digits_1) {
     $divider = ($i == 2) ? 10 : 100;
     $number = floor($no % $divider);
     $no = floor($no / $divider);
     $i += ($divider == 10) ? 1 : 2;
     if ($number) {
        $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
        $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
        $str [] = ($number < 21) ? $words[$number] .
            " " . $digits[$counter] . $plural . " " . $hundred
            :
            $words[floor($number / 10) * 10]
            . " " . $words[$number % 10] . " "
            . $digits[$counter] . $plural . " " . $hundred;
     } else $str[] = null;
  }
  $str = array_reverse($str);
  $result = implode('', $str);
  $points = ($point) ?
    "" . $words[$point / 10] . " " . 
          $words[$point = $point % 10] : '';
if($points){ 
$result = $result . "Rupees  " . $points . " Paise";
}
$result =$result." Only";  
  return ucwords($result); 
}

function make_directory($destination)
{
   if(!is_dir($destination)){ 
     mkdir($destination, 0755); 
   }
} 

function make_nested_directory($destination){
  if(!is_dir($destination)){
     mkdir($destination, 0755,true);
  }
}

// Karza CURL
function karza_curl($config, $payload){
	
	// get the api key and url from config
	$url = $config['api_path'];
	$api_key = $config['api_key'];
	
	// set up header
	$header = array(
		"content-type: application/json",
		"x-karza-key: $api_key"
	);
	
	$curl = curl_init();
	curl_setopt_array($curl, array(
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => "",
        CURLOPT_PROXY=>'10.120.0.83:8080',
        CURLOPT_HTTPPROXYTUNNEL => 1,
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 30,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => "POST",
		CURLOPT_POSTFIELDS => "$payload",
		CURLOPT_HTTPHEADER => $header
	));
	
	$response = curl_exec($curl);
	$err = curl_error($curl);
	
	curl_close($curl);

	if ($err) {
		return array("status"=>"error","message"=>$err);
	} else {
		return array("status"=>"success","response"=>$response);
	}
}

function cbs_api_call($data){

	$curl = curl_init();


	curl_setopt_array($curl, array(

		CURLOPT_URL => $data['url'],

		CURLOPT_RETURNTRANSFER => true,
  
		//CURLOPT_PROXY=>'10.120.0.83:8080',
  
		//CURLOPT_HTTPPROXYTUNNEL => 1,
  
		CURLOPT_ENCODING => '',
  
		CURLOPT_MAXREDIRS => 10,
  
		CURLOPT_TIMEOUT => 0,
  
		CURLOPT_FOLLOWLOCATION => true,
  
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  
		CURLOPT_CUSTOMREQUEST => 'POST',
  
		CURLOPT_POSTFIELDS => $data['body'],
		CURLOPT_HTTPHEADER => array(
		   'Content-Type: application/json'	
		)
	));
	
	$response = curl_exec($curl);
	$err = curl_error($curl);

	curl_close($curl);
//	echo"<pre>";print_r($response);
//	echo"<pre>";print_r($err);die;
	if($err)
		return array("status" => "error", "message" => $err);
	else
		return array("status" => "success", "data" => $response);


}

function create_zip($destination_folder,$DelFilePath,$source_folder){ 
	$zip = new ZipArchive();	
    try{
		if(file_exists($destination_folder.$DelFilePath)) {
				unlink ($destination_folder.$DelFilePath); 				
		}
		
		if ($zip->open($destination_folder.$DelFilePath, ZIPARCHIVE::CREATE) != TRUE) {
			$response = array('status'=>'error', 'message'=>'Could not open archive');
			return $response;
		}
	
	$files=scandir($source_folder,1);

	
	if(!empty($files)){
		foreach($files as $file){ 
			$file_name  = basename($source_folder.$file);
			$ext=pathinfo($source_folder.$file, PATHINFO_EXTENSION);
			
			if(!empty($ext)){
			$zip->addFile($source_folder.$file,$file_name);
			}
		}
		// close and save archive
		$zip->close(); 

		$get_content = file_get_contents($destination_folder.$DelFilePath);
                $encode_string = base64_encode($get_content);

                $response = array('status'=>'success', 'message'=>"file created successfully", 'encode_string' =>$encode_string );
		return $response;
	}else{
		$response = array('status'=>'error', 'message'=>'files not found to make zip');
		return $response;
	}

	
	}catch(Exception $e ){
		$response = array('status'=>'error', 'message'=>$e->getMessage());
		return $response;
	}
	
	
}


function vendor_curl($config){
	
	// get the api key and url from config
	$url = $config['url'];
        $type = $config['type'];
      //  echo "<pre>";print_r(json_encode($config['headers']));
//	echo "<pre>";print_r($config);die;
	$curl = curl_init();
	curl_setopt_array($curl, array(
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true,
                CURLOPT_PROXY=>'10.128.106.4:8080',
                CURLOPT_HTTPPROXYTUNNEL => 1,
		CURLOPT_ENCODING => "",
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 30,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
       // 	CURLOPT_CUSTOMREQUEST => $type,
                CURLOPT_POSTFIELDS => $config['body'],	
         	CURLOPT_HTTPHEADER => $config['headers']
	));

	
	$response = curl_exec($curl);
	$err = curl_error($curl);

	curl_close($curl);

	if ($err) {
		return array("status"=>"error","message"=>$err);
	} else {
		return array("status"=>"success","response"=>$response);
	}
}

function strReplace($data){
	$data = str_replace('"[','[',$data);
	$data = str_replace(']"',']', $data);
	return $data;
   }

//Kisan Tatkal Loan Function
function next_date_calculate($string_date, $number, $next_value){

	$input_date = DateTime::createFromFormat('d/m/Y',$string_date);
	
	if(!empty($number) && !empty($next_value)){
		$input_date->modify($number." ".$next_value);
	}
	$output_date = $input_date->format('Y-m-d');
	$data['result_date'] = $output_date;
	$data['result_day']= date('d',strtotime($output_date));
	$data['result_month']= date('m',strtotime($output_date));
	$data['result_year']= date('Y',strtotime($output_date));

	return $data;
}

// Janasamarth API Curl **//
function los_curl($data){	
  $user_name = $data['headers']['user-name'];
  $api_key = $data['headers']['api-key'];
  // set up header
  $header = array(
    "Content-Type: application/json",
    "user-name: $user_name",
    "api-key: $api_key"
  );

	$curl = curl_init();
	curl_setopt_array($curl, array(
		CURLOPT_URL => $data['url'],
		CURLOPT_RETURNTRANSFER => true,
                CURLOPT_PROXY=>'10.120.0.83:8080',
                CURLOPT_HTTPPROXYTUNNEL => 1,
		CURLOPT_ENCODING => "",
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 30,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => $data['request_type'],
                CURLOPT_POSTFIELDS => $data['payload'],	
		CURLOPT_HTTPHEADER => $header
	));

	
	$response = curl_exec($curl);

	curl_close($curl);
	if ($err) {
		return array("status"=>"error","message"=>$err);
	} else {
		return array("status"=>"success","response"=>$response);
	}
}

/*
function pdf_stamp_old($originalPdfPath,$outputPdfPath,$stampImagePath){
  require_once('/var/www/awesome-enterprise/vendor/setasign/Fpdi/src/autoload.php');
  require_once('/var/www/awesome-enterprise/vendor/setasign/fpdf/fpdf.php');
  require_once('/var/www/awesome-enterprise/vendor/setasign/Fpdi/src/Fpdi.php');

  // Path to the original PDF file
  $originalPdfPath = '/appdata/upload/APP1771932218027199/agreement.PDF';

  // Path to the output PDF file with the stamp
  $outputPdfPath = '/appdata/upload/APP1771932218027199/stamp_agreement.pdf';

  // Path to the stamp image file
  $stampImagePath = '/appdata/stamp.png';

  // Set source PDF file
 // $pdf = new \setasign\Fpdi\Fpdi();
  $pdf = new Fpdi();
  if(file_exists($originalPdfPath)){
      $pagecount = $pdf->setSourceFile($originalPdfPath);
   }else{
    $response = array('status'=>'error', 'message'=>'Source PDF not found');
    return $response;
  }

  // Add watermark to PDF pages
  for($i=1;$i<=$pagecount;$i++){

    $tpl = $pdf->importPage($i);
    $size = $pdf->getTemplateSize($tpl);
    $pdf->addPage();
    $pdf->useTemplate($tpl, 1, 1, $size['width'], $size['height'], TRUE);

  //Put the watermark
    $xxx_final = ($size['width']-50);//42
    $yyy_final = ($size['height']-25); //242
    if($i === $pagecount){
      $pdf->Image($stampImagePath, $xxx_final, $yyy_final, 0, 0, 'png');
    }

  }
  @unlink($stampImagePath);

  // Output the modified PDF to a new file
  $pdf->Output($outputPdfPath, 'I');  //F => For Save //I => For Open
  
 
  $response = array('status'=>'success', 'message'=>"file created successfully");
  return $response;

}
*/

function pdf_stamp($originalPdfPath,$outputPdfPath,$stampImagePath){
  require_once('/var/www/awesome-enterprise/vendor/setasign/Fpdi/src/autoload.php');
  require_once('/var/www/awesome-enterprise/vendor/setasign/fpdf/fpdf.php');
  require_once('/var/www/awesome-enterprise/vendor/setasign/Fpdi/src/Fpdi.php');

   // Path to the original PDF file
 // $originalPdfPath = '/appdata/upload/APP1771932218027199/agreement.PDF';

  // Path to the output PDF file with the stamp
 // $outputPdfPath = '/appdata/upload/APP1771932218027199/stamp_agreement.pdf';

  // Path to the stamp image file
 // $stampImagePath = '/appdata/stamp.png';


  $pfxFile = '/var/www/lt-specific/cert/maha.pfx';
  $pfxPassword = 'nach@1001'; // Replace with the actual password for the PFX file
  $passphrase = 'maha'; // Replace with the passphrase you want to set for the private key

  // Initialize an empty array to store the extracted data
  $certificates = array();

  if (openssl_pkcs12_read(file_get_contents($pfxFile), $certificates, $pfxPassword)) 
{
    $privateKey = $certificates['pkey'];
    $certificate = $certificates['cert'];

    // Export the private key with a passphrase
    $passphraseEncryptedPrivateKey = openssl_pkey_get_private($privateKey,  $passphrase);

    // Generate the public key from the private key and passphrase
    $publicKeyDetails = openssl_pkey_get_details($passphraseEncryptedPrivateKey);
    $publicKey = $publicKeyDetails['key'];

    // Now you have the public key

    /// create new PDF document
    $pdf = new Fpdi();

    if(file_exists($originalPdfPath)){
      $pagecount = $pdf->setSourceFile($originalPdfPath); 
    }else{ 
      $response = array('status'=>'error', 'message'=>'Source PDF not found');
      return $response;
    }
    

    for($i=1;$i<=$pagecount;$i++){ 
      
      $tpl = $pdf->importPage($i); 
      $size = $pdf->getTemplateSize($tpl); 
      $pdf->addPage(); 
      $pdf->useTemplate($tpl, 1, 1, $size['width'], $size['height'], TRUE); 

      $pdf->setSignature($certificate, $privateKey, 'tcpdfdemo');
      
      //Put the watermark 
      $xxx_final = '42';//($size['width']-50); 
      $yyy_final = '242';//($size['height']-25); 
      if($i === $pagecount){  
        $pdf->Image($stampImagePath, $xxx_final, $yyy_final, 0, 0, 'png'); 
      }

      // define active area for signature appearance
      $pdf->setSignatureAppearance(180, 60, 15, 15);

      // *** set an empty signature appearance ***
      $pdf->addEmptySignatureAppearance(180, 80, 15, 15);
    }
   
    //Close and output PDF document
    $pdf->Output($outputPdfPath, 'I');
     $response = array('status'=>'success', 'message'=>"file created successfully");
    return $response;

    }
  
}


/*
function demo(){
 require_once('/var/www/awesome-enterprise/vendor/setasign/Fpdi/src/autoload.php');
  require_once('/var/www/awesome-enterprise/vendor/setasign/fpdf/fpdf.php');
  require_once('/var/www/awesome-enterprise/vendor/setasign/Fpdi/src/Fpdi.php');
require_once('/var/www/awesome-enterprise/vendor/setasign/Fpdi/src/Tcpdf/Fpdi.php');


$data = 'test';
// $privatekey='./certificate/priv.pem';
// The path to your PDF file
$pdfFile = '/appdata/upload/APP1771932218027199/agreement.PDF';

$pfxFilePath = '/var/www/lt-specific/cert/maha.pfx';

$pfxPassword = 'nach@1001';

$publicKey='/var/www/lt-specific/cert/maha.cer'; //bom private
$publicKey=file_get_contents($publicKey);
//$publickey='.maha/public_key.pem';  // public key


    // Load the .PFX file and extract the certificate and private key
    $pfxContent = file_get_contents($pfxFilePath);
    if (openssl_pkcs12_read($pfxContent, $certificates, $pfxPassword)) {
        $certificate = openssl_x509_read($certificates['cert']);
        $privateKey = openssl_pkey_get_private($certificates['pkey'], $pfxPassword);
       // $publicKey = openssl_pkey_get_public($certificates['cert']);

    } else {
        die('Failed to read .PFX file or invalid password.');
    }

//$signature = null;
//echo"<pre>";print_r($certificates);
echo"<pre>";print_r($publicKey);
die;



    $signature = '';
    openssl_sign($data, $signature, $privateKey, OPENSSL_ALGO_SHA1);
  //    echo "<pre>hiiii";print_r($signature);die;
    



// Verify the signature
$verificationResult = openssl_verify($data, $signature, $publicKey, "sha256WithRSAEncryption");

//var_dump($verificationResult);

if ($verificationResult === 0) {
    // Signature is verified; proceed to create the signed PDf
    // Create the signature using the private key
    
    openssl_pkcs7_sign(null, $signature, $data, $privateKey, [], PKCS7_BINARY | PKCS7_DETACHED);

    // Save the signature to a file //certifictae.pem
    //file_put_contents('./certificate/signature.pem', $signature);

    // Create a new FPDI instance with TCPDF
    $pdf = new \setasign\Fpdi\Fpdi();

    // Add a page from the existing PDF
    $pageCount = $pdf->setSourceFile($pdfFile);
    $tplIdx = $pdf->importPage(1);
    $pdf->AddPage();
    $pdf->useTemplate($tplIdx);

    

    // Add your content to the PDF here (e.g., text, images, etc.)

    // Set the signature appearance (optional)
    // Customize the appearance according to your needs
    $pdf->setSignatureAppearance(10, 10, 20, 10);

    // Add the signature to the PDF
  //  $pdf->setSignature('./certificate/signature.pem');

    // Save the signed PDF file
    $outputPath = 'signed_example.pdf';
    $pdf->Output($outputPath, 'I');

    echo "Signature added to the PDF. The signed PDF is saved as: $outputPath";
} else {
    echo "Signature verification failed. Cannot add the signature to the PDF.";
}
}
 */

function pdf_reader($data){
  //require_once('/var/www/bom.thearks.in/awesome-enterprise/vendor/pdfparser-master/alt_autoload.php-dist');
  require_once('/var/www/awesome-enterprise/vendor/pdfparser-master/alt_autoload.php-dist');
  $parser = new \Smalot\PdfParser\Parser();
  $pdf = $parser->parseFile($data['path']);

  $text = $pdf->getText();
  // Split the text into lines
  $lines = explode("\n", $text);
  $sanction_limit = (float) $data['mkcc_sanction_limit'];
  $calculated_sanction_limit = (float) round(($data['mkcc_sanction_limit'] * 100)/110);
  $last_second_year = $data['last_second_year'];
  $last_first_year = $data['last_first_year'];
  $current_year = $data['current_year'];

  // Define a regular expression pattern to match transaction rows
  //$transactionPattern = '/(\d+)\s+(\d{2}\/\d{2}\/\d{4})\s+(.*?)\s+([\d\.-]+)\s+([\d\.-]+)\s+([\d\.-]+)\s+(.*?)\s*/';
 // $transactionPattern = '/(\d+)\s+(\d{2}\/\d{2}\/\d{4})\s+(.*?)\s+([\d\.,-]+)\s+([\d\.,-]+)\s+([\d\.,-]+)\s+(.*?)\s*/';
  $transactionPattern = '/(\d+)\s+(\d{2}\/\d{2}\/\d{4})\s+(.*)\s+([\d\.,-]+)\s+([\d\.,-]+)\s+([\d\.,-]+)\s+(.*?)\s*/';
 // $transactionPattern = '/^\s*(\d+)\s+(\d{2}\/\d{2}\/\d{4})\s+(.+?)\s+([-\d]*)\s+(\$?\d{1,3}(,\d{3})*(\.\d{2})?)\s+(\$?\d{1,3}(,\d{3})*(\.\d{2})?)\s+(\$?\d{1,3}(,\d{3})*(\.\d{2})?)\s+(.+)$/';
 // Match transaction rows using the pattern
  preg_match_all($transactionPattern, $text, $transactionMatches, PREG_SET_ORDER);
//  $transactionMatches = array_reverse($transactionMatches);
  // Initialize the result array for transactions
  $transactions = [];
  $flag = FALSE;
  $flag1 = FALSE;
  $flag2 = FALSE;
  // Process the transaction matches
  foreach ($transactionMatches as $match) {
      // Create an associative array for each transaction
      $transaction = [
          'srno' => $match[1],
          'date' => $match[2],
          'particulars' => $match[3],
        //  'Cheque/Reference No' => $match[4],
          'debit' => $match[4],
          'credit' => $match[5],
          'balance' => $match[6],
          'channel' => $match[7]
      ];
      
      // Add the transaction to the result array
      $transactions[] = $transaction;
      $pattern_1 = "/(\d{2}\/\d{2}\/$last_second_year)/i";  //2021
      $pattern_2 = "/(\d{2}\/\d{2}\/$last_first_year)/i";  //2022
      $pattern_3 = "/(\d{2}\/\d{2}\/$current_year)/i";  //2023

      foreach ($transactions as $transaction) {
        //pattern 3 - Current Year
        if (preg_match($pattern_3, $transaction['date'], $matches)) {
          
          $number = (float) str_replace(',', '', $transaction['debit']);
          if ($number == $sanction_limit || $number >= $calculated_sanction_limit) {  
            $result[$current_year]['present_perfect_renewal_date'] = $transaction['date'];
            $result[$current_year]['present_perfect_renewal_amount'] = $transaction['debit'];
            //$flag = TRUE;
          } 
        }
       
        //if($flag){
        //pattern 2 - Current Year - 1
        if (preg_match($pattern_2, $transaction['date'], $matches)) {
          
          if($result[$current_year]['present_perfect_renewal_amount']!=0){
            
            $new_number = (float) str_replace(',', '', $transaction['debit']);
            $new_sanction_limit = (float)  str_replace(',', '', $result[$current_year]['present_perfect_renewal_amount']);
            $calculated_new_sanction_limit  = ($new_sanction_limit * 100)/110;
            $calculated_new_sanction_limit = round($calculated_new_sanction_limit, -3);
           
            if ($new_number == $new_sanction_limit || $new_number >= $calculated_new_sanction_limit) {
              $result[$last_first_year]['current_renewal_date'] = $transaction['date'];
              $result[$last_first_year]['current_renewal_amount'] = $transaction['debit'];
              //$flag1 = TRUE;
            }
          }else{

            $number = (float) str_replace(',', '', $transaction['debit']);
            //echo $transaction['date']."-----".$number."-----".$sanction_limit."<br/>";
            if ($number == $sanction_limit || $number >= $calculated_sanction_limit) {
              
              $result[$last_first_year]['current_renewal_date'] = $transaction['date'];
              $result[$last_first_year]['current_renewal_amount'] = $transaction['debit'];
              //$flag = TRUE;
            } 
          }
        }
        //}

        //if($flag1){
          //pattern 1 - Current Year - 2
        if (preg_match($pattern_1, $transaction['date'], $matches)) {
          if($result[$last_first_year]['current_renewal_amount']!=0){
            $sec_number = (float) str_replace(',', '', $transaction['debit']);
            $sec_sanction_limit = (float)  str_replace(',', '', $result[$last_first_year]['current_renewal_amount']);
            $calculated_sec_sanction_limit = ($sec_sanction_limit * 100)/110;
            $calculated_sec_sanction_limit = round($calculated_sec_sanction_limit, -3);
            
            if ($sec_number >= $sec_sanction_limit || $sec_number >= $calculated_sec_sanction_limit) {  
              $result[$last_second_year]['last_renewal_date'] = $transaction['date'];
              $result[$last_second_year]['last_renewal_amount'] = $transaction['debit'];
              //$flag2 = TRUE;
            }
          }else{
            $number = (float) str_replace(',', '', $transaction['debit']);
            if ($number == $sanction_limit || $number >= $calculated_sanction_limit) {  
              $result[$last_second_year]['last_renewal_date'] = $transaction['date'];
              $result[$last_second_year]['last_renewal_amount'] = $transaction['debit'];
              //$flag = TRUE;
            } 
          }
        }
        //}
        //echo "new number".$new_number."----- new sanction limit".$new_sanction_limit."<br/>";
        //echo "sec number".$sec_number."----- sec sanction limit".$sec_sanction_limit."<br/>";
      /*  if (preg_match($pattern_2, $transaction['date'], $matches)) {
          $debit = (float) str_replace(',', '', $result[$last_second_year]['last_renewal_amount']);
          $credit = (float) str_replace(',', '', $transaction['credit']);
          if($credit >= $debit){
            $result[$last_second_year]['last_repay_date'] = $transaction['date'];
            $result[$last_second_year]['last_repay_amount'] = $transaction['credit'];
          }
        }

        if (preg_match($pattern_3, $transaction['date'], $matches)) {
          $debit = (float) str_replace(',', '', $result[$last_first_year]['current_renewal_amount']);
          $credit = (float) str_replace(',', '', $transaction['credit']);
          if($credit >= $debit){
            $result[$last_first_year]['current_repay_date'] = $transaction['date'];
            $result[$last_first_year]['current_repay_amount'] = $transaction['credit'];
        } */
    }
  }
  
  //$transactions = array_reverse($transactions);
  $current_repay_amount = 0;
  $last_repay_amount = 0;
  foreach ($transactions as $transaction) {
    $perfect_renewal_date = DateTime::createFromFormat('d/m/Y', $result[$current_year]['present_perfect_renewal_date']);
    $current_renewal_date = DateTime::createFromFormat('d/m/Y', $result[$last_first_year]['current_renewal_date']);
    $last_renewal_date = DateTime::createFromFormat('d/m/Y', $result[$last_second_year]['last_renewal_date']);
    $transaction_date = DateTime::createFromFormat('d/m/Y', $transaction['date']);
    
   
    
    if($last_renewal_date <= $transaction_date && $transaction_date <= $current_renewal_date){
      $credit = (float) str_replace(',', '', $transaction['credit']);
      $last_repay_amount = $last_repay_amount + $credit;
    }
    
    if($current_renewal_date <= $transaction_date && $transaction_date <= $perfect_renewal_date){
      $credit = (float) str_replace(',', '', $transaction['credit']);
      $current_repay_amount = $current_repay_amount + $credit;
    }
  }
  $result[$last_first_year]['current_repay_amount'] = $current_repay_amount;
  $result[$last_second_year]['last_repay_amount'] = $last_repay_amount;

  
  return $result;
}

function pdf_reader_old($data){
  require_once('/var/www/awesome-enterprise/vendor/pdfparser-master/alt_autoload.php-dist');
  $parser = new \Smalot\PdfParser\Parser();
  $pdf = $parser->parseFile($data['path']);

  $text = $pdf->getText();
 
  
  // Split the text into lines
  $lines = explode("\n", $text);
 
  $sanction_limit = round(($data['mkcc_sanction_limit'] * 100)/110);
  $last_second_year = $data['last_second_year'];
  $last_first_year = $data['last_first_year'];
  $current_year = $data['current_year'];

  // Define a regular expression pattern to match transaction rows
  //$transactionPattern = '/(\d+)\s+(\d{2}\/\d{2}\/\d{4})\s+(.*?)\s+([\d\.-]+)\s+([\d\.-]+)\s+([\d\.-]+)\s+(.*?)\s*/';
  $transactionPattern = '/(\d+)\s+(\d{2}\/\d{2}\/\d{4})\s+(.*?)\s+([\d\.,-]+)\s+([\d\.,-]+)\s+([\d\.,-]+)\s+(.*?)\s*/';
  // Match transaction rows using the pattern
  preg_match_all($transactionPattern, $text, $transactionMatches, PREG_SET_ORDER);

//  $transactionMatches = array_reverse($transactionMatches);
  // Initialize the result array for transactions
  $transactions = [];
  $flag = FALSE;
  $flag1 = FALSE;
  $flag2 = FALSE;
  // Process the transaction matches
  foreach ($transactionMatches as $match) {
      // Create an associative array for each transaction
      $transaction = [
          'srno' => $match[1],
          'date' => $match[2],
          'particulars' => $match[3],
        //  'Cheque/Reference No' => $match[4],
          'debit' => $match[4],
          'credit' => $match[5],
          'balance' => $match[6],
          'channel' => $match[7]
      ];

      // Add the transaction to the result array
      $transactions[] = $transaction;
      $pattern_1 = "/(\d{2}\/\d{2}\/$last_second_year)/i";  //2021
      $pattern_2 = "/(\d{2}\/\d{2}\/$last_first_year)/i";  //2022
      $pattern_3 = "/(\d{2}\/\d{2}\/$current_year)/i";  //2023

      
      foreach ($transactions as $transaction) {
        if (preg_match($pattern_3, $transaction['date'], $matches)) {
          $number = (float) str_replace(',', '', $transaction['debit']);
          if ($number >= $sanction_limit) {  
            $result[$current_year]['present_perfect_renewal_date'] = $transaction['date'];
            $result[$current_year]['present_perfect_renewal_amount'] = $transaction['debit'];
            $flag = TRUE;
          } 
        }
    
        if($flag){
          if (preg_match($pattern_2, $transaction['date'], $matches)) {
            $new_number = (float) str_replace(',', '', $transaction['debit']);
            $new_sanction_limit = (float)  str_replace(',', '', $result[$current_year]['present_perfect_renewal_amount']);
            $new_sanction_limit  = ($new_sanction_limit * 100)/110;
            $new_sanction_limit = round($new_sanction_limit, -3);
            if ($new_number >= $new_sanction_limit) {
              $result[$last_first_year]['current_renewal_date'] = $transaction['date'];
              $result[$last_first_year]['current_renewal_amount'] = $transaction['debit'];
              $flag1 = TRUE;
            }
          }
        }

        if($flag1){
          if (preg_match($pattern_1, $transaction['date'], $matches)) {
            $sec_number = (float) str_replace(',', '', $transaction['debit']);
            $sec_sanction_limit = (float)  str_replace(',', '', $result[$last_first_year]['current_renewal_amount']);
            $sec_sanction_limit = ($sec_sanction_limit * 100)/110;
            $sec_sanction_limit = round($sec_sanction_limit, -3);
            if ($sec_number >= $sec_sanction_limit) {  
              $result[$last_second_year]['last_renewal_date'] = $transaction['date'];
              $result[$last_second_year]['last_renewal_amount'] = $transaction['debit'];
              $flag2 = TRUE;
            }
          }
        }

      /*  if (preg_match($pattern_2, $transaction['date'], $matches)) {
          $debit = (float) str_replace(',', '', $result[$last_second_year]['last_renewal_amount']);
          $credit = (float) str_replace(',', '', $transaction['credit']);
          if($credit >= $debit){
            $result[$last_second_year]['last_repay_date'] = $transaction['date'];
            $result[$last_second_year]['last_repay_amount'] = $transaction['credit'];
          }
        }

        if (preg_match($pattern_3, $transaction['date'], $matches)) {
          $debit = (float) str_replace(',', '', $result[$last_first_year]['current_renewal_amount']);
          $credit = (float) str_replace(',', '', $transaction['credit']);
          if($credit >= $debit){
            $result[$last_first_year]['current_repay_date'] = $transaction['date'];
            $result[$last_first_year]['current_repay_amount'] = $transaction['credit'];
        } */
    }
  }
  
  // get repay amount
  $current_repay_amount = 0;
  $last_repay_amount = 0;
  foreach ($transactions as $transaction) {
    $perfect_renewal_date = DateTime::createFromFormat('d/m/Y', $result[$current_year]['present_perfect_renewal_date']);
    $current_renewal_date = DateTime::createFromFormat('d/m/Y', $result[$last_first_year]['current_renewal_date']);
    $last_renewal_date = DateTime::createFromFormat('d/m/Y', $result[$last_second_year]['last_renewal_date']);
    $transaction_date = DateTime::createFromFormat('d/m/Y', $transaction['date']);
    
   
    
    if($last_renewal_date <= $transaction_date && $transaction_date <= $current_renewal_date){
      $credit = (float) str_replace(',', '', $transaction['credit']);
      $last_repay_amount = $last_repay_amount + $credit;
    }
    
    if($current_renewal_date <= $transaction_date && $transaction_date <= $perfect_renewal_date){
      $credit = (float) str_replace(',', '', $transaction['credit']);
      $current_repay_amount = $current_repay_amount + $credit;
    }
  }
  $result[$last_first_year]['current_repay_amount'] = $current_repay_amount;
  $result[$last_second_year]['last_repay_amount'] = $last_repay_amount;

  
//  echo"<pre>";print_r($result);
//echo "<pre>"; print_r($transactions );
  return $result;
}

function cbs_resp_decryption($encData, $securityKey, $ivValue){
   $encByteArray = base64_decode($encData);
   $encryptionKey = $securityKey;
   $ivstring = $ivValue;
   // Create key and IV
   $secretKey = mb_substr($encryptionKey, 0, 32, '8bit'); // Ensure key is 32 bytes (256 bits)
   $iv = mb_substr($ivstring, 0, 16, '8bit');  // Ensure IV is 16 bytes
   // Create Cipher objectOPENSSL_RAW_DATA | OPENSSL_NO_PADDING
   $cipher = openssl_get_cipher_methods('AES-256-CBC');
   $decrypt = openssl_decrypt($encByteArray, 'AES-256-CBC', $secretKey, OPENSSL_RAW_DATA | OPENSSL_NO_PADDING, $iv);
   
   // Decrypt data
   $decryptedText = utf8_decode($decrypt);  // Decode UTF-8 output
   return $decryptedText;
}
function is_base64($string){
	if(preg_match('/^[a-zA-Z0-9\/\r\n+]*={0,2}$/', $string)){
		$decoded = base64_decode($string, true);
		return $decoded !== false && base64_encode($decoded) === $string;
	}
	return false;
}
function pad_with_zero($input, $length){
        return str_pad($input, $length, "0", STR_PAD_LEFT);
}

function name_match_percent_old($name1, $name2) {
    // Convert names to lowercase and split them into words
    $name1Words = explode(" ", strtolower($name1));
    $name2Words = explode(" ", strtolower($name2));

    // Sort the words to ignore the order
    sort($name1Words);
    sort($name2Words);

    // Initialize total similarity and match counts
    $totalSimilarity = 0;
    $wordCount = count($name1Words) + count($name2Words); // Total number of words in both names

    // Compare each word from name2 against each word in name1
    foreach ($name1Words as $word1) {

        $bestMatch = 0;
        foreach ($name2Words as $word2) {

            similar_text($word1, $word2, $similarity);
            if ($similarity > $bestMatch) {
                $bestMatch = $similarity;
            }
        }
        $totalSimilarity += $bestMatch;
    }

    // Calculate the percentage similarity
    $averageSimilarity = ($totalSimilarity / count($name1Words)); // Average similarity across name1
    return round($averageSimilarity, 2);
}
 function name_match_percent($name1, $name2){
        // Convert names to lowercase and split them into words
        $name1Words = explode(" ", strtolower($name1));
        $name2Words = explode(" ", strtolower($name2));

        // Sort the words to ignore the order
        sort($name1Words);
        sort($name2Words);

        $name1Words = implode(',', $name1Words);
        $name2Words = implode(',',$name2Words);

        // Initialize total similarity and match counts
        $totalSimilarity = 0;
        similar_text($name1Words, $name2Words, $totalSimilarity);

        // Calculate the percentage similarity
        return $totalSimilarity;
    }

function remove_duplicate($arr, $keyName){
	$values = array_column($arr, $keyName);
	$uniqueValues = array_unique($values);
	$uniqueData = [];
	foreach ($arr as $item) {
		if (in_array($item[$keyName], $uniqueValues)) { 
			$uniqueData[] = $item; 
			unset($uniqueValues[array_search($item[$keyName], $uniqueValues)]);
		}
	}
	return $uniqueData;
}

function validate_user_input($input){
	return preg_match("/['\";#%*()=<>`]|--/",$input);
}
